VIERNES AI — paquete preparado para Netlify + Gemini

QUÉ INCLUYE
- public/index.html: interfaz web de VIERNES AI con chat, micrófono y voz del navegador.
- netlify/functions/chat.mjs: función de servidor que consulta Gemini sin exponer la clave en el navegador.
- netlify.toml: configuración de publicación y funciones.

IMPORTANTE
- No subas ni pegues GEMINI_API_KEY en index.html, GitHub, mensajes o capturas.
- Configura la clave únicamente en Netlify > Site configuration / Environment variables.
- El nivel gratuito de Gemini tiene límites y Google puede usar contenido del nivel gratuito para mejorar productos; no envíes información privada o sensible.
- Para menores, un padre/madre/tutor debe ayudar a gestionar las cuentas, clave y condiciones del proveedor.
- El código privado reduce el acceso casual, pero no sustituye límites de uso profesionales. No compartas el código ni el enlace públicamente. No se garantiza que el nivel gratuito esté disponible para todos los modelos/cuentas o que las cuotas no cambien.

CÓMO PUBLICAR (resumen desde Android)
1. Extrae este ZIP. Conserva exactamente la estructura de carpetas.
2. Sube los archivos a un repositorio privado de GitHub usando la web: public/index.html, netlify/functions/chat.mjs y netlify.toml. Mantén las carpetas.
3. En Netlify, conecta el repositorio con “Add new project / Import an existing project” o vincula el repositorio a tu sitio existente si aparece esa opción. Si importas un proyecto nuevo, Netlify puede darte un enlace nuevo.
4. En configuración de despliegue, usa Publish directory = public y Functions directory = netlify/functions (netlify.toml ya lo define). Deja el build command vacío si no pide otro.
5. En Netlify > Site configuration > Environment variables, agrega GEMINI_API_KEY con la clave creada/gestionada por tu adulto de confianza. Agrega también VIERNES_ACCESS_CODE con un código privado nuevo que no sea una contraseña que uses en otros sitios. No pongas ninguna de estas dos variables en el código. Al abrir el chat, la página pedirá el código privado.
6. Vuelve a Deploys y lanza un nuevo deploy. Abre el enlace y prueba un mensaje.

Si una pantalla no coincide con estos nombres, no compartas claves ni pagues; dime qué opciones aparecen y te guío.
