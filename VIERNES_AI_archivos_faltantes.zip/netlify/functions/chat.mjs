// VIERNES AI — Netlify Function. La clave se guarda como variable de entorno.
export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Método no permitido" }, { status: 405 });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  const requiredAccessCode = process.env.VIERNES_ACCESS_CODE;
  if (!apiKey) {
    return Response.json({ error: "El servidor no tiene configurada la clave de IA." }, { status: 503 });
  }

  try {
    const body = await request.json();
    if (!requiredAccessCode || typeof body.accessCode !== "string" || body.accessCode !== requiredAccessCode) {
      return Response.json({ error: "Código de acceso incorrecto." }, { status: 401 });
    }
    if (typeof body.message !== "string" || !body.message.trim()) {
      return Response.json({ error: "Escribe un mensaje." }, { status: 400 });
    }
    if (body.message.length > 3000) {
      return Response.json({ error: "El mensaje es demasiado largo. Prueba con menos de 3000 caracteres." }, { status: 413 });
    }

    // Solo conservar una parte pequeña del historial para limitar uso.
    const history = Array.isArray(body.history) ? body.history.slice(-10) : [];
    const contents = [];
    for (const item of history) {
      if (!item || typeof item.content !== "string") continue;
      const role = item.role === "assistant" ? "model" : "user";
      const content = item.content.slice(0, 3000);
      if (contents.length && contents[contents.length - 1].role === role) {
        contents[contents.length - 1].parts[0].text += "\n" + content;
      } else {
        contents.push({ role, parts: [{ text: content }] });
      }
    }
    if (!contents.length || contents[contents.length - 1].role !== "user") {
      contents.push({ role: "user", parts: [{ text: body.message.trim() }] });
    } else {
      contents[contents.length - 1].parts[0].text += "\n" + body.message.trim();
    }

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "Eres VIERNES, una asistente personal de IA amigable, útil y futurista. Responde en español claro, con tono natural y apropiado para adolescentes. Sé honesta si no sabes algo. No afirmes haber realizado acciones que no hiciste. No solicites contraseñas, claves secretas ni datos privados." }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      // No revelar la respuesta completa del proveedor ni la clave en logs/cliente.
      const status = response.status === 429 ? 429 : 502;
      return Response.json({ error: status === 429 ? "Se alcanzó el límite gratuito temporal. Inténtalo más tarde." : "El proveedor de IA rechazó la solicitud. Revisa la configuración de la clave y el modelo." }, { status });
    }

    const reply = (data.candidates?.[0]?.content?.parts || [])
      .map(part => typeof part.text === "string" ? part.text : "")
      .join("\n").trim();
    if (!reply) return Response.json({ error: "La IA no devolvió texto. Inténtalo otra vez." }, { status: 502 });
    return Response.json({ reply });
  } catch (error) {
    return Response.json({ error: "No se pudo procesar el mensaje. Inténtalo otra vez." }, { status: 500 });
  }
};
